package org.openbot.env;

public interface IDataReceived {
  void dataReceived(String command);
}
