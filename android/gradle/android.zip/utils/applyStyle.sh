#!/bin/bash

java -jar google-java-format-1.7-all-deps.jar -r `find ../app/src -type f -name *java`
